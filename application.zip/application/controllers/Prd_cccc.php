public function detail($id_prd) {
        $data['page'] = 'DETAIL PREDIKSI';
        $data['active'] = 'prd';
        $where = array ('id_prd' => $id_prd);
        $data['detail'] = $this->Prd_m->detail($where,'tb_prediksi')->result();
        $data['nama_detail'] = $this->Prd_m->detail($where,'tb_prediksi')->result_array();

        // $data['nama_detail'] = $this->Prd_m->get()->result();
        // $nama_detail = [];
        // foreach ($data['nama_detail'] as $item) {
        //     // sort($item);
        //     array_push($nama_detail, $item->nm_obat);
        //     // array_push($chart, $item->nm_obat);
        // }
        // $data['nama_detail'] = $nama_detail;
        // $data['chart'] = $this->Prd_m->chart();

        /*$data['rincian'] = $this->Prd_m->detail($where,'tb_prediksi')->result_array();
        $rincian = [];
        foreach ($data['rincian'] as $item) {
            sort($item);
            $implode = implode('',$item);
            $explode = explode(',',$implode);
            $intval = array_map('intval',$explode);
            if (count($intval) >= 6) {
                array_push($rincian, $intval);
            } else if (count($intval) < 6) {
                array_push($rincian, $intval);
            }            
        }
*/
        // $data['sum'] = $rincian;


        // $data['hitung'] = $this->Prd_m->getHitung($where,'tb_prediksi')->result_array();

        // =============== DATA NAMA OBAT

        $data['bulan_detail'] = $this->Prd_m->getBulan_Detail()->result_array();

        $bulan = [];
        foreach ($data['bulan_detail'] as $item) {
            sort($item);
            $implode = implode('',$item);
            $explode_bulan = explode(',',$implode);
            $intval = array_map('intval',$explode_bulan);
            array_push($bulan, $intval);
        }
        // var_dump($bulan);
        $data['bulan'] = $explode_bulan;

        // =======================================================

        $data['hitung'] = $this->Prd_m->getHitung()->result_array();
        
        $angka_butuh = [];
        foreach ($data['hitung'] as $item) {
            sort($item);
            $implode = implode('',$item);
            $explode_butuh = explode(',',$implode);
            $intval = array_map('intval',$explode_butuh);
            array_push($angka_butuh, $intval);

        }
        $data['butuh'] = $explode_butuh;


        // ================================================

        $kebutuhan = [];
        for ($i=0; $i < count($bulan); $i++) {
            for ($j=0; $j < count($angka_butuh); $j++) {
                // if ($nama[$j] == $data['nama_detail'][$l]['nm_obat']) {
                    $p_row = [
                        'bulan' => $bulan[$i],
                        'angka_butuh' => $angka_butuh[$j]
                    ];
                    array_push($kebutuhan, $p_row);
                    // unset($bulan[$i]);
                    // $nama = array_values($bulan);
                // }
            }
        }

        // ========================================


        // =============== DATA NAMA OBAT

        $data['nama'] = $this->Prd_m->getNameData()->result();

        $nama = [];
        foreach ($data['nama'] as $item) {
            array_push($nama, $item->nm_obat);
        }
        $data['name'] = $nama;

        

        // =============== START PERHITUNGAN PREDIKSI

        $result = [];
        for ($j=0; $j < count($nama); $j++) {
            // for ($k=0; $k < count($kebutuhan); $k++) {
            for ($k=0; $k < count($angka_butuh); $k++) {
                for ($l=0; $l < count($data['nama_detail']); $l++) {
                    for ($m=0; $m < count($bulan); $m++) {
                        if ($nama[$j] == $data['nama_detail'][$l]['nm_obat']) {
                            $p_row = [
                                'nm_obat' => $nama[$j],
                                // 'bulan' => $bulan[$j],
                                // 'kebutuhan' => $kebutuhan[$k]
                                'bulan' => implode('',$bulan[$m]),
                                'angka_butuh' => implode('',$angka_butuh[$k])
                            ];
                            array_push($result, $p_row);
                            unset($nama[$j]);
                            $nama = array_values($nama);
                        }
                    }
                }
            }
        }

        var_dump($result);

        $data['rinci_bulan'] = explode(',',$result->bulan);
        $data['rinci_butuh'] = explode(',',$result->angka);

        // $chart = [];
        // $data['chart'] = $this->Prd_m->chart()->result_array();
        // // sort($data['chart']);
        // foreach ($data['chart'] as $item) {
        //     sort($item);
        //     $implode = implode('',$item);
        //     array_push($chart, $implode);
        // }
        // // $data['grafik'] = $chart;
        // // $data['name'] = $nama;

        // $tampil = [];
        // for ($j=0; $j < count($nama); $j++) {
        //     for ($k=0; $k < count($chart); $k++) {
        //         /*var_dump($chart[$j]);
        //         echo "<br>";
        //         var_dump($nama[$k]);*/

        //         /*sort($chart[$j]);
        //         sort($nama[$k]);*/

        //         $c_row = [
        //             $nama[$j] => $chart[$k]
        //         ];

        //         array_push($tampil, $c_row);
        //         unset($nama[$j]);
        //         $nama = array_values($nama);
        //     }
        // }
        
        // $data['grafik'] = $tampil;

        // $data['a'] = $this->Prd_m->getHitung()->result_array();

        /*$result = [];
        foreach ($data['chart'] as $item) {
            $implode = implode('',$item);
            $explode = explode(',',$implode);
            $intval = array_map('intval',$explode);
            $sum = array_sum($intval);
            array_push($result, $intval);
        }

        $data['grafik'] = $result;*/

        /*$result = [];
        foreach ($data['chart'] as $item) {
            array_push($result, $item);
        }
        $data['grafik'] = $result;*/

        // $data['anl'] = $this->Anl_m->get()->result();
        $this->template->views('Prediksi/detail_prediksi', $data);
    }