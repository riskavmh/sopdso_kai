<div class="container-fluid">
  <div class="row">
    <div class="col-12">
        <div class="card">

        <div class="card-header">
          <h4 class="mt-2 card-title text-bold text-center"><?= $page ?></h4>

          <h4 class="mt-1 card-title float-right">
            <a href="<?= base_url('Kdl_c/tambah')?>" class="btn bg-navy btn-icon-split float-right">
              <i class="fas fa-plus"></i>
              <span class="text">&nbsp;Tambah Data</span>
            </a>
          </h4>
        </div>

          <div class="card-body">
            <table id="tb_kdl" class="table table-bordered" style="width: 100%">
              <thead >
              <tr>
                <th>No.</th>
                <th>Nama Obat</th>
                <th>Satuan Terkecil</th>
                <th>No Batch</th>
                <th>Kedaluwarsa</th>
                <th style="width: 9%"></th>
              </tr>
              </thead>
              <tbody>
              <?php $no = 1;
                  foreach ($kdl as $baris) {

                    date_default_timezone_set("Asia/Jakarta");
                    $today = date('Y-m-d');
                    $today = strtotime($today);
                    // var_dump($today);
                    $expire = strtotime($baris->tgl_kdl);
                    $a = ($expire-$today);
                    $b = floor($a / (24*60*60*30));

              ?>
              <tr class="<?php echo (($b >= 0) && ($b <= 6)) ? 'bg-danger' : ((($b > 6) && ($b <= 12)) ? 'bg-warning' : ''); ?>">
                <td><?= $no++; ?></td>
                <td><?= $baris->nm_obat; ?></td>
                <td><?= $baris->stn_kcl; ?></td>
                <td><?= $baris->no_batch; ?></td>
                <td><?php $exp = date("d-m-Y",strtotime($baris->tgl_kdl)); echo $exp; ?></td>
                <td>
                  <a href="<?= base_url('Kdl_c/ubah/'.$baris->id_kdl) ?>" class="btn btn-dark btn-sm" title="Ubah">
                    <span class="fas fa-pencil-alt"></span>
                  </a>
                  <a href="<?= base_url('Kdl_c/delete/'.$baris->id_kdl) ?>" onclick="return confirm('Yakin hapus data?')" class="btn btn-secondary btn-sm" title="Hapus">
                    <span class="fas fa-trash"></span>
                  </a>
                </td>
              </tr>

              <?php
                }
              ?>

              </tbody>

            </table>
            
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</div>

