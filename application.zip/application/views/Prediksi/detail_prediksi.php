<div class="container-fluid">
  <?php foreach($detail as $baris) { ?>
  <div class="card">
    <div class="card-header border-0">
      <div class="d-flex justify-content-between">
        <h3 class="card-title text-bold text-lg"><?= $baris->nm_obat; ?></h3>
        <!-- <a href="javascript:void(0);">View Report</a> -->
      </div>
    </div>
  </div>
  <div class="row">
    
    <div class="col-7">
      <div class="card">
        <!-- <div class="card-header">
          <h4 class="mt-2 card-title">DAFTAR NAMA OBAT</h4>
        </div> -->
        <!-- /.card-header -->

        <div class="card-body">
          <table id="example4" class="table table-bordered table-hover" style="width: 100%">
            <thead>
              <?php

               // $this->load->view('convertDate');

                  date_default_timezone_set("Asia/Jakarta");
                  $kebutuhan = this_m();
                  // $next = date("m",strtotime('+1 months'));
                  $prediksi = next_1m();
              ?>
            <tr>
              <th>No.</th>
              <th>Bulan dan Tahun</th>
              <th>Kebutuhan Obat<!-- <?= $kebutuhan ?> --></th>
              <th>Prediksi <?= $prediksi ?></th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;
            ?>
            <tr>
              <td><?= $no++; ?></td>
            </tr>
            <?php

                foreach ($detail as $key => $value) {
                      print_r($value);
                      echo "<br>";
                  }

                  foreach ($kebutuhan as $item) {
                      print_r($item->datanya);
                      echo "<br>";
                  }
            ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->

      </div>
      <!-- /.card -->

      <div class="card">
        <div class="card-footer">
          <a href="<?= base_url('Prd_c')?>" class="btn btn-secondary">
            <span class="text">Kembali</span>
          </a>
        </div>
      </div>

    </div>
    <!-- /.col -->
  
    <div class="col-5">

      <div class="card">

        <div class="card-body">

          <div class="d-flex">
            <p class="d-flex flex-column">
              <span class="text-bold text-lg">Grafik</span>
              <span>Kebutuhan Obat <?= $baris->nm_obat; ?></span>
            </p>
            <p class="ml-auto d-flex flex-row text-right mt-4 text-sm">
              <span class="mr-2">
              <i class="fas fa-square" style="color:#638ec9;"></i> Tahun ini
            </span>

            <span>
              <i class="fas fa-square" style="color:#dbdbdb;"></i> Tahun lalu
            </span>
            </p>
          </div>

          <div class="position-relative">
            <canvas id="myChart" style="width:100%;max-width:700px; height: 250px;"></canvas>
            <?php
              //Inisialisasi nilai variabel awal
              // $nama_jurusan = "";
              // $butuh = null;
              // foreach ($hasil as $item)
              // {
                  // $jur = $item->jurusan;
                  // $nama_jurusan .= "'$jur'". ", ";
                /*foreach ($chart as $key => $value) {
                    
                  $lalu = $value->butuh_lalu;
                  $butuh .= "'$lalu'". ", ";

                }*/
              // }
            ?>
          </div>
          
        </div>
        <!-- /.card body -->
      </div>
      <!-- /.card -->

    </div>
    <!-- /.col-md-6 -->

  </div>
<?php } ?>
</div>


