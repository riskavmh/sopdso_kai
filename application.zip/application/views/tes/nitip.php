	<!-- <script>
		/*function showPrompt() {
			var x;
	        var site = prompt("Masukkan Data", "");
        	if (site != null) {
            	x = site;
            	document.getElementById("demo").value = x;
			}
		}*/
	</script> -->
	<div class="limiter">
		<h1>Simple Moving Average</h1>

		<div>
			<div>
				<?php if (!count($prd)) {
					echo "<p class='subJudul'> No Records </p>";
				} else {
				?>
				<div>
					<table border="1">
						<thead>
							<tr>
								<th>No</th>
								<th>Bulan</th>
								<th>Nama Obat</th>
								<th>Butuh_lalu</th>
								<th>Fore 6 Bln</th>
								<th>MAD 6 Bln</th>
								<th>MSE 6 Bln</th>
								<th>MAPE 6 Bln</th>
							</tr>
						</thead>
						<tbody>
							<?php $no = 1; ?>
							<?php foreach ($prd as $baris) { ?>

								<tr>
									<td><?= $no++; ?></td>
									<td><?= $baris->bulan; ?>/<?= $baris->tahun; ?></td>
									<td><?= $baris->nm_obat; ?></td>
									<!-- <td><?= abs($baris->butuh_lalu); ?></td> -->
									<!-- <td><?= abs($baris->butuh_skrg); ?></td> -->
									<td><?= $baris->butuh_lalu; ?></td>
									<td><?= $baris->butuh_skrg; ?></td>
									<td><?= $baris->mad; ?></td>
									<td><?= $baris->mse; ?></td>
									<td><?= $baris->mape; ?>%</td>
								</tr>
							<?php } ?>

						</tbody>
					</table>
				</div>

				<?php } ?>
					<br>
					<?php
					// foreach ($hitung as $h) {
					  	// echo "butuh_lalu<br>";
					  	// var_dump($hitung);
					  	// echo "<br>";
					  	echo "butuh_lalu tampil<br>";
					  	var_dump($tampil);
					  	echo "<br><br>";
					  	/*echo "a1<br>";
					  	var_dump($a1);
					  	echo "<br>";*/
					  // } 
                    ?>
					<!-- <div>
						<form action="Prd_c/prediksi" method="post">
							<input id="demo" type="hidden" name="inputData" value=""></input>
							<button class="purple-bg" id="butuh_lalu" name="input" onclick="showPrompt()">Input Data</button>
							<button class="purple-bg" id="butuh_skrg" name="prediksi">Prediksi Bulan Depan</button>
						</form>
					</div> -->

					<hr>
					<a href="Main/data_kdl">Data Kedaluwarsa</a>
					<a href="Main/data_anl">Data Analisis</a>
					<a href="Main/prediksi">Prediksi Kebutuhan</a>
				</div>
			</div>
		</div>



	</div>
