<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<? //echo $before[0].' '.$before[1] ?><br>
	<? //echo $after[0].' '.$after[1] ?>
	<? //echo count($satu); ?>


	<h3>merged</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>STOK GUDANG</td>
			<td>PEMBELIAN 1</td>
			<td>PEMBELIAN 2</td>
			<!-- <td>PERMINTAAN PB</td>
			<td>PERMINTAAN BW</td>
			<td>PERMINTAAN JR</td> -->
			<!-- <td>STOK NYATA</td> -->
			<td>KEBUTUHAN</td>
			<!-- <td>BUFFER</td> -->
			<!-- <td>KURANG</td> -->
			<!-- <td>ORDER</td> -->
		</tr>
		<?php $no=1; foreach ($dua as $x): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><b><?= $x['nm_obat'] ?></b></td>
			<td><b><?= $x['stn_kcl'] ?></b></td>
			<td><b><?= $x['stok_gdg'] ?></b></td>
			<td><b><?= $x['beli1'] ?></b></td>
			<td><b><?= $x['beli2'] ?></b></td>
			<!-- <td><b><?= $x['minta_pb'] ?></b></td>
			<td><b><?= $x['minta_bw'] ?></b></td>
			<td><b><?= $x['minta_jr'] ?></b></td> -->
			<!-- <td><?= $x['stok_nyata'] ?></td> -->
			<td><b><?= $x['butuh_bln'] ?></b></td>
			<!-- <td><?= $x['butuh_buffer'] ?></td> -->
			<!-- <td><?= $x['kurang'] ?></td> -->
			<!-- <td><?= $x['jml_order'] ?></td> -->
		</tr>
		<?php endforeach ?>

	
	</table>

	<br><hr><br>


	<h3>stok</h3>
	<table border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>SISA AWAL</td>
			<td>PENERIMAAN</td>
			<td>JUMLAH</td>
			<td>PEMAKAIAN</td>
			<td>SISA AKHIR</td>
		</tr>
		<?php foreach ($excel['file_stok'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<br><hr><br>

	<h3>penggunaan</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>	
			<td>JUMLAH TERCANTUM DALAM RESEP</td>
			<td>SATUAN TERKECIL</td>
			<td>HARGA OBAT (SATUAN)</td>
			<td>JUMLAH HARGA</td>
		</tr>
		<?php foreach ($excel['file_guna'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<br><hr><br>

	<h3>pembelian</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>________</td>
			<td>________</td>
			<td>________</td>
			<td>PEMBELIAN 1</td>
			<td>________</td>
			<td>PEMBELIAN 2</td>
		</tr>
		<?php foreach ($excel['file_beli'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<br><hr><br>

	<h3>permintaan</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>PERMINTAAN PB</td>
			<td>PERMINTAAN BW</td>
			<td>PERMINTAAN JR</td>
		</tr>
		<?php foreach ($excel['file_minta'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<hr>
</body>
</html>