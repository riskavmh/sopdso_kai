<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<!-- <h3>ANALISIS</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>STOK GUDANG</td>
			<td>PEMBELIAN 1</td>
			<td>PEMBELIAN 2</td>
			<td>PERMINTAAN PB</td>
			<td>PERMINTAAN BW</td>
			<td>PERMINTAAN JR</td>
			<td>STOK NYATA</td>
			<td>KEBUTUHAN</td>
			<td>KEBUTUHAN PLUS BUFFER</td>
			<td>KEKURANGAN</td>
			<td>ORDER</td>
		</tr>
		<?php $no=1; foreach ($analisis as $m): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><?= $m['nm_obat'] ?></td>
			<td><?= $m['stn_kcl'] ?></td>
			<td><?= $m['stok_gdg'] ?></td>
			<td><?= $m['beli1'] ?></td>
			<td><?= $m['beli2'] ?></td>
			<td><?= $m['minta_pb'] ?></td>
			<td><?= $m['minta_bw'] ?></td>
			<td><?= $m['minta_jr'] ?></td>
			<td><?= $m['stok_nyata'] ?></td>
			<td><?= $m['butuh_bln'] ?></td>
			<td><?= $m['butuh_buffer'] ?></td>
			<td><?= $m['kurang'] ?></td>
			<td><?= $m['jml_order'] ?></td>
		</tr>
		<?php endforeach ?>
	</table>

	<hr><br><br><hr> -->

	<h3>ANALISIS</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>BULAN DAN TAHUN</td>
			<!-- <td>TAHUN</td> -->
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>BUTUH_LALU</td>
		</tr>
		<?php $no=1; foreach ($kurang as $x): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><?= $x['bulan_tahun'] ?></td>
			<!-- <td><?= $x['tahun'] ?></td> -->
			<td><?= $x['nm_obat'] ?></td>
			<td><?= $x['stn_kcl'] ?></td>
			<td><?= abs($x['butuh_lalu']) ?></td>
		</tr>
		<?php endforeach ?>
	</table>

	<hr><br><br><hr>

	<h3>PREDIKSI</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>BULAN DAN TAHUN</td>
			<!-- <td>TAHUN</td> -->
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>BUTUH_LALU</td>
			<!-- <td>TERAKHIR</td> -->
			<td>BUTUH_SKRG</td>
			<td>MAD</td>
			<!-- <td>MSD</td> -->
			<!-- <td>MAPE</td> -->
		</tr>
		<?php $no=1; foreach ($prediksi as $p): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><?= $p['bulan_tahun'] ?></td>
			<!-- <td><?= $p['tahun'] ?></td> -->
			<td><?= $p['nm_obat'] ?></td>
			<td><?= $p['stn_kcl'] ?></td>
			<td><?= abs($p['butuh_lalu']) ?></td>
			<!-- <td><?= abs($x['terakhir']) ?></td> -->
			<td><?= abs($p['butuh_skrg']) ?></td>
			<td><?= abs($p['mad']) ?></td>
			<!-- <td><?= abs($p['msd']) ?></td> -->
			<!-- <td><?= abs($p['mape']) ?></td> -->
		</tr>
		<?php endforeach ?>

	
	</table>
</body>
</html>