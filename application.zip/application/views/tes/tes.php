<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<? echo $before[0].' '.$before[1] ?><br>
	<? echo $after[0].' '.$after[1] ?>

	<h3>merged</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>STOK GUDANG</td>
			<td>PEMBELIAN 1</td>
			<td>PEMBELIAN 2</td>
			<td>PERMINTAAN PB</td>
			<td>PERMINTAAN BW</td>
			<td>PERMINTAAN JR</td>
			<td>KEBUTUHAN</td>
		</tr>
		<?php $no=1; foreach ($merged as $x): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><?= $x['nm_obat'] ?></td>
			<td><?= $x['stn_kcl'] ?></td>
			<td><?= $x['stok_gdg'] ?></td>
			<td><?= $x['beli1'] ?></td>
			<td><?= $x['beli2'] ?></td>
			<td><?= $x['minta_pb'] ?></td>
			<td><?= $x['minta_bw'] ?></td>
			<td><?= $x['minta_jr'] ?></td>
			<td><?= $x['butuh_bln'] ?></td>
		</tr>
		<?php endforeach ?>
	</table>

	<hr><br><br><hr>

	<h3>stok</h3>
	<table border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>SISA AWAL</td>
			<td>PENERIMAAN</td>
			<td>JUMLAH</td>
			<td>PEMAKAIAN</td>
			<td>SISA AKHIR</td>
		</tr>
		<?php foreach ($excel['file_stok'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<hr><br><br><hr>

	<h3>penggunaan</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>JENIS OBAT</td>	
			<td>JUMLAH TERCANTUM DALAM RESEP</td>
			<td>SATUAN TERKECIL</td>
			<td>HARGA OBAT (SATUAN)</td>
			<td>JUMLAH HARGA</td>
		</tr>
		<?php foreach ($excel['file_guna'] as $x): ?>
		<tr>
			<?php foreach ($x as $l): ?>
				<td><?= $l ?></td>
			<?php endforeach ?>
		</tr>
		<?php endforeach ?>
	</table>

	<hr>
</body>
</html>