<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<table border="1">
		<tr>
			<th>No.</th>
			<th>Nama Obat</th>
			<!-- <th>Jenis Obat</th> -->
			<!-- <th>Satuan Terkecil</th> -->
			<!-- <th>No Batch</th> -->
			<th>Kedaluwarsa</th>
			<th>Tanggal Sekarang</th>
			<th>Selisih</th>
		</tr>
		<?php $no = 1;
		foreach ($kdl as $baris) { ?>
		<tr>
			<td><?= $no++; ?></td>
            <td><?= $baris->nm_obat; ?></td>
            <!-- <td><?= $baris->jns_obat; ?></td> -->
            <!-- <td><?= $baris->stn_kcl; ?></td> -->
            <!-- <td><?= $baris->no_batch; ?></td> -->
            <!-- <td><?= $baris->bulan; ?>-<?= $baris->tahun; ?></td> -->
            <td><?= $baris->tgl_kdl; ?></td>
            <td><?= date('Y-m-d'); ?></td>
            <td><?php

		            $tgl_kdl = new DateTime($baris->tgl_kdl);
		            $tgl_skrg = new DateTime();
		            // $beda = $tgl_kdl->diff($tgl_skrg);
		            $beda  = date_diff($tgl_skrg, $tgl_kdl);
		            echo $beda->format('%R%a');

		        ?>
            </td>

		</tr>
		<?php } ?>
	</table>
	<hr>
	<a href="Main/data_kdl">Data Kedaluwarsa</a>  <a href="Main/data_anl">Data Analisis</a>
</body>
</html>