<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<!-- <h3>UNMERGED</h3>
	<table border="1">
		<tr>
			<th>nm_obat</th>
			<th>stn_kcl</th>
			<th>stok_gdg</th>
			<th>beli1</th>
			<th>beli2</th>
			<th>minta_pb</th>
			<th>minta_bw</th>
			<th>minta_jr</th>
			<th>stok_nyata</th>
			<th>butuh_bln</th>
			<th>butuh_buffer</th>
			<th>kurang</th>
			<th>jml_order</th>
		</tr>
		<?php foreach ($excel['unmerged'] as $s): ?>
			<tr>
				<td><?= $s['nm_obat'] ?></td>
				<td><?= $s['stn_kcl'] ?></td>
				<td><?= $s['stok_gdg'] ?></td>
				<td><?= $s['beli1'] ?></td>
				<td><?= $s['beli2'] ?></td>
				<td><?= $s['minta_pb'] ?></td>
				<td><?= $s['minta_bw'] ?></td>
				<td><?= $s['minta_jr'] ?></td>
				<td><?= $s['stok_nyata'] ?></td>
				<td><?= $s['butuh_bln'] ?></td>
				<td><?= $s['butuh_buffer'] ?></td>
				<td><?= $s['kurang'] ?></td>
				<td><?= $s['jml_order'] ?></td>
			</tr>
		<?php endforeach ?>
	</table> -->
	<h3>SGBM</h3>
	<table border="1">
		<tr>
			<th>no.</th>
			<th>bulan_tahun</th>
			<th>nm_obat</th>
			<th>stn_kcl</th>
			<th>stok_gdg</th>
			<th>beli1</th>
			<th>beli2</th>
			<th>minta_pb</th>
			<th>minta_bw</th>
			<th>minta_jr</th>
			<th>stok_nyata</th>
			<th>butuh_bln</th>
			<th>angka_buffer</th>
			<th>butuh_buffer</th>
			<th>kurang</th>
			<th>jml_order</th>
		</tr>
		<?php $no = 1; foreach ($merged as $s): ?>
			<tr>
				<td><?= $no++; ?></td>
				<td><?= $s['bulan_tahun'] ?></td>
				<td><?= $s['nm_obat'] ?></td>
				<td><?= $s['stn_kcl'] ?></td>
				<td><?= $s['stok_gdg'] ?></td>
				<td><?= $s['beli1'] ?></td>
				<td><?= $s['beli2'] ?></td>
				<td><?= $s['minta_pb'] ?></td>
				<td><?= $s['minta_bw'] ?></td>
				<td><?= $s['minta_jr'] ?></td>
				<td><?= $s['stok_nyata'] ?></td>
				<td><?= $s['butuh_bln'] ?></td>
				<td><?= $s['angka_buffer'] ?></td>
				<td><?= $s['butuh_buffer'] ?></td>
				<td><?= $s['kurang'] ?></td>
				<td><?= $s['jml_order'] ?></td>
			</tr>
		<?php endforeach ?>
	</table>

	<!-- <pre><?= var_export($excel['merged']) ?></pre> -->
</body>
</html>