<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<h3>KEDALUWARSA</h3>
	<table  border="1">
		<tr>
			<td>NO</td>
			<td>NAMA OBAT</td>
			<td>SATUAN TERKECIL</td>
			<td>NO BATCH</td>
			<td>TANGGAL KDL</td>
			<td>UPDATE</td>
		</tr>
		<?php $no=1; foreach ($edit as $m): ?>
		<tr>
			<td><?= $no++  ?></td>
			<td><?= $m['nm_obat'] ?></td>
			<td><?= $m['stn_kcl'] ?></td>
			<td><?= $m['no_batch'] ?></td>
			<td><?= $m['tgl_kdl'] ?></td>
			<td><?= $m['up_date'] ?></td>
		</tr>
		<?php endforeach ?>
	</table>
</body>
</html>