<footer class="main-footer">

  <font color="white" class="text-xs">programmed by : riskavmh</font>
  <div class="float-right d-none d-sm-inline-block">
    <strong>Copyright &copy; 2022 - All rights reserved. </strong>
  </div>
  
</footer>