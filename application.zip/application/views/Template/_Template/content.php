<section class="content">

    <?php echo $main; ?>
    
</section>