<!-- REQUIRED SCRIPTS -->

	<!-- jQuery -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/jquery/jquery.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/jquery/jquery-ui.min.js"></script>
	<!-- Bootstrap -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/dist/js/adminlte.js"></script>
	<!-- AdminLTE -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/dist/js/adminlte.js"></script>

	<!-- DataTables  & Plugins -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/jszip/jszip.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/pdfmake/pdfmake.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/pdfmake/vfs_fonts.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
	<!-- AdminLTE App -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/dist/js/adminlte.min.js"></script>

	<!-- Bootstrap 4 -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>	
	<!-- Select2 -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/select2/js/select2.full.min.js"></script>
	<!-- bs-custom-file-input -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>

	<!-- SweetAlert2 -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/sweetalert2/sweetalert2.min.js"></script>
	<!-- Toastr -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/toastr/toastr.min.js"></script>
	
	<!-- fullCalendar 2.2.5 -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/moment/moment.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/fullcalendar/main.js"></script>
	
	<!-- InputMask -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/moment/moment.min.js"></script>
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/inputmask/jquery.inputmask.min.js"></script>
	<!-- date-range-picker -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/daterangepicker/daterangepicker.js"></script>
	
	<!-- Tempusdominus Bootstrap 4 -->
	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

	<script src="<?=base_url('assets');?>/vendor/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	
